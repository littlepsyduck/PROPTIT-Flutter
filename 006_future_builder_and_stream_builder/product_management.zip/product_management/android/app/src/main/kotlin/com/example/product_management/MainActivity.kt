package com.example.product_management

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
